import pandas as pd
import re

def find_marks_column(df):
    keywords = ["marks", "score", "total", "percentage"]

    for col in df.columns:
        if any(k in col.lower() for k in keywords):
            return col

    numeric_cols = df.select_dtypes(include=["number"]).columns
    return numeric_cols[0] if len(numeric_cols) > 0 else None


def clean_marks_series(series):
    cleaned = series.astype(str).str.extract(r"(\d+\.?\d*)")[0]
    return pd.to_numeric(cleaned, errors="coerce")


def marks_summary(df):
    marks_col = find_marks_column(df)

    if marks_col is None:
        return {"Error": "No marks-like column found"}

    marks = clean_marks_series(df[marks_col])

    return {
        "Marks Column Used": marks_col,
        "Valid Entries": int(marks.notna().sum()),
        "Average Marks": round(marks.mean(), 2),
        "Highest Marks": marks.max(),
        "Lowest Marks": marks.min()
    }


def top_students(df, top_n=10):
    marks_col = find_marks_column(df)

    if marks_col is None:
        return df

    df = df.copy()
    df["__clean_marks__"] = clean_marks_series(df[marks_col])

    return (
        df.sort_values(by="__clean_marks__", ascending=False)
          .head(top_n)
          .drop(columns="__clean_marks__")
    )
