import pandas as pd

def find_salary_column(df):
    keywords = ["salary", "ctc", "pay", "wage", "income"]
    for col in df.columns:
        if any(k in col.lower() for k in keywords):
            return col
    return None

def employee_summary(df):
    salary_col = find_salary_column(df)
    if salary_col is None:
        return {"Error": "No salary column found"}

    salary = pd.to_numeric(df[salary_col], errors="coerce")

    return {
        "Salary Column Used": salary_col,
        "Total Employees": len(df),
        "Average Salary": round(salary.mean(skipna=True), 2),
        "Max Salary": salary.max(skipna=True),
        "Min Salary": salary.min(skipna=True)
    }

def payroll_list(df):
    salary_col = find_salary_column(df)
    if salary_col is None:
        return df

    salary = pd.to_numeric(df[salary_col], errors="coerce")
    result = df.copy()
    result["Salary"] = salary
    return result[["Salary"]]

def top_10_paid(df):
    salary_col = find_salary_column(df)
    if salary_col is None:
        return df

    salary = pd.to_numeric(df[salary_col], errors="coerce")
    df = df.copy()
    df["_salary_"] = salary

    return (
        df.sort_values("_salary_", ascending=False)
          .head(10)
          .drop(columns="_salary_")
    )