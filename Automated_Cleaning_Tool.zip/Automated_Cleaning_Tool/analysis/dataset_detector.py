def detect_dataset_type(df):
    cols = [c.lower().replace(" ", "").replace("_", "") for c in df.columns]

    employee_keywords = [
        "empid", "employeeid", "employee",
        "salary", "ctc", "pay", "wage", "income",
        "department", "designation"
    ]

    student_keywords = [
        "studentid", "rollno", "rollnumber",
        "marks", "score", "total", "percentage",
        "grade", "subject"
    ]

    emp_score = sum(any(k in c for k in employee_keywords) for c in cols)
    stu_score = sum(any(k in c for k in student_keywords) for c in cols)

    if emp_score >= 2:
        return "employee"
    elif stu_score >= 2:
        return "student"
    else:
        return "generic"
