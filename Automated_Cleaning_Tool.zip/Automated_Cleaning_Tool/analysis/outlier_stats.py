import numpy as np

def outlier_percentage(df):
    numeric_df = df.select_dtypes(include=["number"])
    if numeric_df.empty:
        return 0

    outlier_count = 0
    total_values = 0

    for col in numeric_df.columns:
        data = numeric_df[col].dropna()
        if data.empty:
            continue

        Q1 = np.percentile(data, 25)
        Q3 = np.percentile(data, 75)
        IQR = Q3 - Q1

        lower = Q1 - 1.5 * IQR
        upper = Q3 + 1.5 * IQR

        outlier_count += ((data < lower) | (data > upper)).sum()
        total_values += len(data)

    return round((outlier_count / total_values) * 100, 2) if total_values else 0
