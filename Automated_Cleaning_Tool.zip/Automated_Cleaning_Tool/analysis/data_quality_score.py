from analysis.outlier_stats import outlier_percentage

def compute_quality_score(df, missing_percent, duplicate_rows):
    total_rows = df.shape[0]
    duplicate_percent = (duplicate_rows / total_rows) * 100 if total_rows else 0

    # ✅ Safety guard
    try:
        outlier_percent = outlier_percentage(df)
    except:
        outlier_percent = 0

    score = 100 \
            - (missing_percent * 0.4) \
            - (duplicate_percent * 0.3) \
            - (outlier_percent * 0.3)

    return max(round(score, 2), 0)