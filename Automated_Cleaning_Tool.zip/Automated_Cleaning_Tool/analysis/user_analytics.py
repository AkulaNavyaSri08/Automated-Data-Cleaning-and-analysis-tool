import pandas as pd

def descriptive_stats(df, columns):
    return df[columns].describe().T


def groupby_analysis(df, group_col, target_col, agg_func):
    grouped = df.groupby(group_col, as_index=False)[target_col].agg(agg_func)
    return grouped



def top_k_analysis(df, target_col, k=10, ascending=False):
    return df.sort_values(by=target_col, ascending=ascending).head(k)


def threshold_filter(df, col, operator, value):
    if operator == ">":
        return df[df[col] > value]
    elif operator == "<":
        return df[df[col] < value]
    elif operator == ">=":
        return df[df[col] >= value]
    elif operator == "<=":
        return df[df[col] <= value]
    elif operator == "==":
        return df[df[col] == value]
    else:
        return df


def correlation_analysis(df):
    return df.select_dtypes(include="number").corr()
