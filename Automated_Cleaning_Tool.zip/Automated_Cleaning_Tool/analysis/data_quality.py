import pandas as pd

def data_quality_summary(df: pd.DataFrame):
    total_rows = df.shape[0]
    total_cols = df.shape[1]

    missing_cells = df.isnull().sum().sum()
    total_cells = total_rows * total_cols
    missing_percent = (missing_cells / total_cells) * 100 if total_cells else 0

    duplicate_rows = df.duplicated().sum()

    numeric_cols = df.select_dtypes(include=["number"]).columns.tolist()
    categorical_cols = df.select_dtypes(exclude=["number"]).columns.tolist()

    return {
        "Total Rows": total_rows,
        "Total Columns": total_cols,
        "Missing Cells": missing_cells,
        "Missing Percentage (%)": round(missing_percent, 2),
        "Duplicate Rows": duplicate_rows,
        "Numeric Columns": len(numeric_cols),
        "Categorical Columns": len(categorical_cols)
    }
