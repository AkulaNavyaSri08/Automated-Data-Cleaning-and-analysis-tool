def generic_overview(df):
    return {
        "Total Rows": df.shape[0],
        "Total Columns": df.shape[1],
        "Numeric Columns": len(df.select_dtypes(include=["number"]).columns),
        "Categorical Columns": len(df.select_dtypes(exclude=["number"]).columns)
    }


def numeric_analysis(df):
    numeric_df = df.select_dtypes(include=["number"])
    if numeric_df.empty:
        return None
    return numeric_df.describe().T


def categorical_analysis(df, top_n=5):
    cat_df = df.select_dtypes(exclude=["number"])
    summaries = {}

    for col in cat_df.columns:
        summaries[col] = cat_df[col].value_counts().head(top_n)

    return summaries
